import json
import os
import boto3
import base64
from typing import Dict, Any, Optional
import requests
from datetime import datetime
import subprocess
import tempfile

def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for deploying to EKS clusters using boto3 and K8s API directly.
    
    Event structure:
    {
        "target": "backend" | "gateway" | "both",
        "action": "deploy" | "status" | "rollback" | "test",
        "manifests": {
            "backend": [...],
            "gateway": [...]
        },
        "image_tag": "latest" or specific tag
    }
    """
    
    # Get environment variables
    backend_cluster = os.environ['BACKEND_CLUSTER_NAME']
    gateway_cluster = os.environ['GATEWAY_CLUSTER_NAME']
    backend_endpoint = os.environ['BACKEND_CLUSTER_ENDPOINT']
    gateway_endpoint = os.environ['GATEWAY_CLUSTER_ENDPOINT']
    backend_ca = os.environ['BACKEND_CLUSTER_CA']
    gateway_ca = os.environ['GATEWAY_CLUSTER_CA']
    backend_ecr = os.environ['BACKEND_ECR_URL']
    gateway_ecr = os.environ['GATEWAY_ECR_URL']
    region = os.environ['REGION']
    
    # Parse event
    target = event.get('target', 'both')
    action = event.get('action', 'deploy')
    image_tag = event.get('image_tag', 'latest')
    
    # Special test action to verify Lambda is working
    if action == 'test':
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Lambda is working',
                'environment': {
                    'backend_cluster': backend_cluster,
                    'gateway_cluster': gateway_cluster,
                    'backend_endpoint': backend_endpoint[:50] + '...',
                    'gateway_endpoint': gateway_endpoint[:50] + '...',
                    'region': region
                }
            })
        }
    
    results = {}
    
    # Process backend if needed
    if target in ['backend', 'both']:
        k8s_client = EKSClient(
            cluster_name=backend_cluster,
            endpoint=backend_endpoint,
            ca_data=backend_ca,
            region=region
        )
        
        if action == 'deploy':
            results['backend'] = deploy_to_cluster(
                k8s_client, 
                'backend',
                f"{backend_ecr}:{image_tag}"
            )
        elif action == 'status':
            results['backend'] = get_deployment_status(k8s_client, 'backend')
        elif action == 'rollback':
            results['backend'] = rollback_deployment(k8s_client, 'backend')
    
    # Process gateway if needed
    if target in ['gateway', 'both']:
        k8s_client = EKSClient(
            cluster_name=gateway_cluster,
            endpoint=gateway_endpoint,
            ca_data=gateway_ca,
            region=region
        )
        
        if action == 'deploy':
            results['gateway'] = deploy_to_cluster(
                k8s_client,
                'gateway',
                f"{gateway_ecr}:{image_tag}"
            )
        elif action == 'status':
            results['gateway'] = get_deployment_status(k8s_client, 'gateway')
        elif action == 'rollback':
            results['gateway'] = rollback_deployment(k8s_client, 'gateway')
    
    return {
        'statusCode': 200,
        'body': json.dumps(results)
    }


class EKSClient:
    """Client for interacting with EKS cluster using boto3 and K8s API."""
    
    def __init__(self, cluster_name: str, endpoint: str, ca_data: str, region: str):
        self.cluster_name = cluster_name
        self.endpoint = endpoint
        self.ca_data = ca_data
        self.region = region
        self.session = boto3.Session(region_name=region)
        
        # Get EKS token
        self.token = self._get_eks_token()
        
        # Setup session for K8s API calls
        self.k8s_session = requests.Session()
        self.k8s_session.headers.update({
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json'
        })
        
        # Save CA cert for SSL verification
        self.ca_file = f'/tmp/{cluster_name}-ca.crt'
        with open(self.ca_file, 'w') as f:
            f.write(base64.b64decode(ca_data).decode('utf-8'))
    
    def _get_eks_token(self) -> str:
        """Get EKS bearer token using boto3."""
        import urllib.parse
        from botocore import awsrequest
        from botocore.auth import SigV4Auth
        
        # This replicates what aws eks get-token does
        credentials = self.session.get_credentials()
        
        # Create a presigned URL for the get-caller-identity request
        request = awsrequest.AWSRequest(
            method='GET',
            url=f'https://sts.{self.region}.amazonaws.com/',
            headers={'x-k8s-aws-id': self.cluster_name},
            params={
                'Action': 'GetCallerIdentity',
                'Version': '2011-06-15'
            }
        )
        
        # Sign with SigV4
        SigV4Auth(credentials, 'sts', self.region).add_auth(request)
        
        # Build the full URL with all parameters
        presigned_url = request.url
        
        # Format headers as URL parameters for the presigned URL
        header_params = []
        for key, value in request.headers.items():
            if key != 'Host':
                header_params.append(f'{key}={urllib.parse.quote(value, safe="")}')
        
        if header_params:
            presigned_url += ('&' if '?' in presigned_url else '?') + '&'.join(header_params)
        
        # EKS token format
        token = 'k8s-aws-v1.' + base64.urlsafe_b64encode(
            presigned_url.encode('utf-8')
        ).decode('utf-8').rstrip('=')
        
        return token
    
    def api_request(self, method: str, path: str, data: Optional[Dict] = None) -> Dict:
        """Make a request to the Kubernetes API."""
        url = f"{self.endpoint}{path}"
        
        try:
            response = self.k8s_session.request(
                method=method,
                url=url,
                json=data,
                verify=self.ca_file,
                timeout=30
            )
            
            if response.status_code >= 400:
                # Add debugging info for auth errors
                error_msg = f"API error {response.status_code}: {response.text}"
                if response.status_code == 401:
                    error_msg += f"\nToken (first 50 chars): {self.token[:50]}..."
                    error_msg += f"\nEndpoint: {self.endpoint}"
                return {
                    'success': False,
                    'error': error_msg
                }
            
            return {
                'success': True,
                'data': response.json() if response.text else {}
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def apply_manifest(self, manifest: Dict) -> Dict:
        """Apply a Kubernetes manifest."""
        kind = manifest.get('kind', '').lower()
        metadata = manifest.get('metadata', {})
        name = metadata.get('name')
        namespace = metadata.get('namespace', 'default')
        
        # Map kinds to API paths
        api_paths = {
            'deployment': f'/apis/apps/v1/namespaces/{namespace}/deployments',
            'service': f'/api/v1/namespaces/{namespace}/services',
            'configmap': f'/api/v1/namespaces/{namespace}/configmaps',
            'networkpolicy': f'/apis/networking.k8s.io/v1/namespaces/{namespace}/networkpolicies'
        }
        
        path = api_paths.get(kind)
        if not path:
            return {'success': False, 'error': f'Unsupported kind: {kind}'}
        
        # Try to update first, then create if not exists
        update_result = self.api_request('PATCH', f'{path}/{name}', manifest)
        if update_result['success']:
            return {'success': True, 'action': 'updated', 'resource': f'{kind}/{name}'}
        
        # If update failed, try to create
        create_result = self.api_request('POST', path, manifest)
        if create_result['success']:
            return {'success': True, 'action': 'created', 'resource': f'{kind}/{name}'}
        
        return create_result


def deploy_to_cluster(k8s_client: EKSClient, cluster_type: str, image_url: str) -> Dict:
    """Deploy manifests to a cluster."""
    
    manifests = get_manifests(cluster_type, image_url)
    results = []
    
    for manifest in manifests:
        result = k8s_client.apply_manifest(manifest)
        results.append(result)
    
    return {
        'cluster': cluster_type,
        'deployments': results
    }


def get_deployment_status(k8s_client: EKSClient, cluster_type: str) -> Dict:
    """Get status of deployments in a cluster."""
    
    result = k8s_client.api_request('GET', '/apis/apps/v1/deployments')
    
    if result['success']:
        deployments = result['data'].get('items', [])
        return {
            'cluster': cluster_type,
            'status': 'success',
            'deployments': [
                {
                    'name': d['metadata']['name'],
                    'namespace': d['metadata']['namespace'],
                    'replicas': d['status'].get('replicas', 0),
                    'ready': d['status'].get('readyReplicas', 0)
                }
                for d in deployments
            ]
        }
    else:
        return {
            'cluster': cluster_type,
            'status': 'error',
            'error': result['error']
        }


def rollback_deployment(k8s_client: EKSClient, cluster_type: str) -> Dict:
    """Rollback deployments in a cluster."""
    
    # Get all deployments
    result = k8s_client.api_request('GET', '/apis/apps/v1/deployments')
    
    if not result['success']:
        return {'cluster': cluster_type, 'status': 'error', 'error': result['error']}
    
    rollback_results = []
    deployments = result['data'].get('items', [])
    
    for deployment in deployments:
        name = deployment['metadata']['name']
        namespace = deployment['metadata']['namespace']
        
        # Trigger rollback by updating deployment
        rollback_result = k8s_client.api_request(
            'PATCH',
            f'/apis/apps/v1/namespaces/{namespace}/deployments/{name}',
            {
                'spec': {
                    'template': {
                        'metadata': {
                            'annotations': {
                                'kubectl.kubernetes.io/restartedAt': datetime.utcnow().isoformat()
                            }
                        }
                    }
                }
            }
        )
        
        rollback_results.append({
            'deployment': f"{namespace}/{name}",
            'success': rollback_result['success'],
            'error': rollback_result.get('error')
        })
    
    return {
        'cluster': cluster_type,
        'rollbacks': rollback_results
    }


def get_manifests(cluster_type: str, image_url: str) -> list:
    """Get Kubernetes manifests for a cluster type."""
    
    if cluster_type == 'backend':
        return [
            {
                'apiVersion': 'apps/v1',
                'kind': 'Deployment',
                'metadata': {
                    'name': 'backend-service',
                    'namespace': 'default',
                    'labels': {'app': 'backend', 'layer': 'backend'}
                },
                'spec': {
                    'replicas': 2,
                    'selector': {'matchLabels': {'app': 'backend'}},
                    'template': {
                        'metadata': {'labels': {'app': 'backend'}},
                        'spec': {
                            'containers': [{
                                'name': 'backend',
                                'image': image_url,
                                'ports': [{'containerPort': 8080}],
                                'resources': {
                                    'requests': {'memory': '128Mi', 'cpu': '100m'},
                                    'limits': {'memory': '256Mi', 'cpu': '200m'}
                                }
                            }]
                        }
                    }
                }
            },
            {
                'apiVersion': 'v1',
                'kind': 'Service',
                'metadata': {
                    'name': 'backend-service',
                    'namespace': 'default',
                    'labels': {'app': 'backend'}
                },
                'spec': {
                    'selector': {'app': 'backend'},
                    'ports': [{'port': 80, 'targetPort': 8080, 'protocol': 'TCP'}]
                }
            }
        ]
    
    elif cluster_type == 'gateway':
        return [
            {
                'apiVersion': 'v1',
                'kind': 'ConfigMap',
                'metadata': {
                    'name': 'nginx-config',
                    'namespace': 'default'
                },
                'data': {
                    'default.conf': '''
server {
    listen 80;
    server_name _;
    
    location /health {
        access_log off;
        return 200 "healthy\\n";
        add_header Content-Type text/plain;
    }
    
    location / {
        proxy_pass http://backend-service.default.svc.cluster.local;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
'''
                }
            },
            {
                'apiVersion': 'apps/v1',
                'kind': 'Deployment',
                'metadata': {
                    'name': 'gateway-proxy',
                    'namespace': 'default',
                    'labels': {'app': 'gateway', 'layer': 'gateway'}
                },
                'spec': {
                    'replicas': 2,
                    'selector': {'matchLabels': {'app': 'gateway'}},
                    'template': {
                        'metadata': {'labels': {'app': 'gateway'}},
                        'spec': {
                            'containers': [{
                                'name': 'nginx',
                                'image': 'nginx:alpine',
                                'ports': [{'containerPort': 80}],
                                'volumeMounts': [{
                                    'name': 'nginx-config',
                                    'mountPath': '/etc/nginx/conf.d'
                                }],
                                'resources': {
                                    'requests': {'memory': '64Mi', 'cpu': '50m'},
                                    'limits': {'memory': '128Mi', 'cpu': '100m'}
                                }
                            }],
                            'volumes': [{
                                'name': 'nginx-config',
                                'configMap': {'name': 'nginx-config'}
                            }]
                        }
                    }
                }
            },
            {
                'apiVersion': 'v1',
                'kind': 'Service',
                'metadata': {
                    'name': 'gateway-service',
                    'namespace': 'default',
                    'labels': {'app': 'gateway'}
                },
                'spec': {
                    'type': 'LoadBalancer',
                    'selector': {'app': 'gateway'},
                    'ports': [{'port': 80, 'targetPort': 80, 'protocol': 'TCP'}]
                }
            }
        ]
    
    return []